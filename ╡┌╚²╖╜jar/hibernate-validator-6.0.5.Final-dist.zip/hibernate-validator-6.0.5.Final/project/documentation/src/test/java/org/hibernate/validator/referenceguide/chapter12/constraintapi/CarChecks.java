package org.hibernate.validator.referenceguide.chapter12.constraintapi;

public interface CarChecks {
}
